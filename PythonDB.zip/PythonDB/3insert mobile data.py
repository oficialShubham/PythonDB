import pymysql

pi=int(input('Enter prodid : '))
mn=input('Enter modelname : ')
cny=input('Enter company : ')
cty=input('Enter connectivity : ')
rm=input('enter ram: ')
rom=input('enter rom: ')
clr=input('enter color: ')
srn=input('enter sreen: ')
bry=input('enter battery: ')
psr=input('enter processor: ')
prc=input('enter price: ')
rtg=float(input('enter rating: '))
con=pymysql.connect(host='bunw6ivhjghvuxi8cux8-mysql.services.clever-cloud.com',user='uxyaugktvzhsfjja',password='Zd93QxPZnJTemqVx7pUb',database='bunw6ivhjghvuxi8cux8')
curs=con.cursor()

curs.execute("insert into mobile values(%d,'%s','%s','%s','%s','%s','%s','%s','%s','%s','%s',%.2f)" %(pi,mn,cny,cty,rm,rom,clr,srn,bry,psr,prc,rtg))
con.commit()
print('mobile data stored in the cloud')

con.close()