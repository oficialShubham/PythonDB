import pymysql

con=pymysql.connect(host='bunw6ivhjghvuxi8cux8-mysql.services.clever-cloud.com',user='uxyaugktvzhsfjja',password='Zd93QxPZnJTemqVx7pUb',database='bunw6ivhjghvuxi8cux8')
curs=con.cursor()
curs.execute('select * from mobile')
data=curs.fetchall()
print(data)

con.close()