import pymysql

con=pymysql.connect(host='bunw6ivhjghvuxi8cux8-mysql.services.clever-cloud.com',user='uxyaugktvzhsfjja',password='Zd93QxPZnJTemqVx7pUb',database='bunw6ivhjghvuxi8cux8')
curs=con.cursor()
no=int(input('Enter mobile modelname : '))
curs.execute("select * from mobile where modelname=%d" %no )
data=curs.fetchone()

print(data)

con.close()