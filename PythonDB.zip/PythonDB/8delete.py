import pymysql

con=pymysql.connect(host='bunw6ivhjghvuxi8cux8-mysql.services.clever-cloud.com',user='uxyaugktvzhsfjja',password='Zd93QxPZnJTemqVx7pUb',database='bunw6ivhjghvuxi8cux8')
curs=con.cursor()

no=int(input('Enter prodid : '))
curs.execute("select * from mobile where prodid=%d" %no)
data=curs.fetchone()

if data:
    curs.execute("delete from mobile where prodid=%d" %no)
    con.commit()
    print('mobile deleted successfully')
else:
    print('mobile does not exist')

con.close()